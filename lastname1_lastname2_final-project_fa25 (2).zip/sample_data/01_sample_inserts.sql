SET search_path TO eda;

INSERT INTO plan_product (product_code, product_name, product_type, metal_tier, network_type)
VALUES
 ('PPO-001','NY Metro PPO Silver','PPO','Silver','Broad'),
 ('HMO-010','NY Metro HMO Bronze','HMO','Bronze','Narrow')
ON CONFLICT DO NOTHING;

INSERT INTO member (external_member_id, first_name, last_name, date_of_birth, sex, email, city, state, postal_code)
VALUES
 ('M-1001','Alex','Chen','1989-04-12','M','alex.chen@example.com','New York','NY','10001'),
 ('M-1002','Mia','Zhang','1975-09-30','F','mia.zhang@example.com','Brooklyn','NY','11201')
ON CONFLICT DO NOTHING;

INSERT INTO policy (policy_number, member_id, product_id, effective_date, policy_status)
SELECT 'POL-90001', m.member_id, p.product_id, '2025-01-01', 'Active'
FROM member m, plan_product p
WHERE m.external_member_id='M-1001' AND p.product_code='PPO-001'
ON CONFLICT DO NOTHING;

INSERT INTO provider (npi, provider_name, provider_type, specialty, city, state, postal_code)
VALUES
 ('1234567890','Downtown Clinic','Clinic','Primary Care','New York','NY','10001'),
 ('2223334445','Metro Hospital','Hospital','Inpatient','New York','NY','10016')
ON CONFLICT DO NOTHING;

-- Encounter + diagnosis + claim
WITH m AS (SELECT member_id FROM member WHERE external_member_id='M-1001'),
     pr AS (SELECT provider_id FROM provider WHERE npi='1234567890')
INSERT INTO encounter (member_id, provider_id, encounter_start, encounter_end, encounter_type, facility_name)
SELECT m.member_id, pr.provider_id, '2025-03-01 10:00', '2025-03-01 10:30', 'outpatient', 'Downtown Clinic'
FROM m, pr;

INSERT INTO diagnosis (encounter_id, icd10_code, diagnosis_desc, is_primary)
SELECT e.encounter_id, 'E11.9', 'Type 2 diabetes mellitus without complications', TRUE
FROM encounter e
ORDER BY e.encounter_id DESC
LIMIT 1;

WITH pol AS (SELECT policy_id FROM policy WHERE policy_number='POL-90001'),
     e AS (SELECT encounter_id FROM encounter ORDER BY encounter_id DESC LIMIT 1),
     pr AS (SELECT provider_id FROM provider WHERE npi='1234567890')
INSERT INTO claim (claim_number, policy_id, encounter_id, provider_id, claim_received_dt, claim_status,
                   total_billed_amt, total_allowed_amt, total_paid_amt)
SELECT 'CLM-70001', pol.policy_id, e.encounter_id, pr.provider_id, '2025-03-03', 'Paid',
       250.00, 180.00, 160.00
FROM pol, e, pr
ON CONFLICT DO NOTHING;

INSERT INTO claim_line (claim_id, line_number, service_from_dt, service_to_dt, cpt_hcpcs_code, units, billed_amt, allowed_amt, paid_amt)
SELECT c.claim_id, 1, '2025-03-01', '2025-03-01', '99213', 1, 250.00, 180.00, 160.00
FROM claim c WHERE c.claim_number='CLM-70001'
ON CONFLICT DO NOTHING;

INSERT INTO payment (claim_id, payment_date, payment_method, paid_amt, check_eft_number)
SELECT c.claim_id, '2025-03-10', 'EFT', 160.00, 'EFT-ABC-001'
FROM claim c WHERE c.claim_number='CLM-70001'
ON CONFLICT DO NOTHING;

INSERT INTO data_source (source_name, source_type, ingestion_method, owner)
VALUES ('Member Survey','Survey','batch','Analytics Team')
ON CONFLICT DO NOTHING;

INSERT INTO risk_factor (member_id, factor_type, factor_value, observed_date, source)
SELECT member_id, 'smoking', 'never', '2025-02-15', 'survey'
FROM member WHERE external_member_id='M-1001';

INSERT INTO unstructured_document (member_id, source_id, doc_type, doc_uri, doc_hash, extracted_json)
SELECT m.member_id, s.source_id, 'survey_free_text', 'azure://datalake/raw/surveys/M-1001/2025-02-15.json', 'hash-placeholder',
       '{"sentiment":"neutral","topics":["diet","exercise"]}'::jsonb
FROM member m, data_source s
WHERE m.external_member_id='M-1001' AND s.source_name='Member Survey';
