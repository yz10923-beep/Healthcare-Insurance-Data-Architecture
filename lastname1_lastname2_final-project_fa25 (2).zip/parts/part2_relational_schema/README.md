# Part 2 – Relational Schema

See:
- `sql/schema/01_create_tables.sql`
- `sql/schema/02_constraints.sql`
- `sql/schema/03_indexes.sql`
