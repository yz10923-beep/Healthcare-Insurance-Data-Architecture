# Part 1 – Conceptual Model

## Business scope (insurance ODS + hybrid analytics)
This conceptual ER model supports:
- Member enrollment into a plan product via a policy
- Encounters with providers and associated diagnoses/procedures
- Claims submitted and adjudicated at header + line level, with payments
- Risk factors (SDoH / lifestyle) linked to members
- Unstructured documents (e.g., surveys, notes, social posts) linked into a data lake with optional NLP output (`extracted_json`)

## ER diagram
- `er_diagram.png` – rendered diagram
- `er_diagram.dot` – Graphviz source (easy to edit)
