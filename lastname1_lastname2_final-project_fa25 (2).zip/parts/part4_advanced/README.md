# Part 4 – Advanced / Physical Design

See:
- `sql/advanced/part4_advanced.sql`
- `docs/physical_design.md`
