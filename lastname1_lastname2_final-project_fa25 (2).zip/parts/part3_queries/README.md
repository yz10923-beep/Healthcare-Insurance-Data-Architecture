# Part 3 – Queries

See `sql/queries/part3_queries.sql` for report/analytics queries that join:
- structured ODS tables (members, policies, claims, encounters)
- hybrid/unstructured artifacts (`unstructured_document.extracted_json`)
