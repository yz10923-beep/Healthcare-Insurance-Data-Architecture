# Healthcare Insurance Data Architecture (Parts 1–4)

This repo contains a **submit-ready** software portion for a course project on building an Enterprise Data Architecture (EDA) for a healthcare insurance use case.

## Repo structure
- `parts/part1_conceptual/` – ER diagram (conceptual) + short notes
- `parts/part2_relational_schema/` – logical/relational schema + DDL
- `parts/part3_queries/` – EDA/ODS queries for reporting/analytics
- `parts/part4_advanced/` – physical design optimizations (indexes, views, partitions-ready patterns)
- `sql/schema/` – DDL scripts
- `sql/queries/` – query scripts
- `sql/advanced/` – optional optimizations
- `sample_data/` – small sample inserts to sanity-check the schema

## How to run (PostgreSQL)
1. Create an empty database (e.g., `health_insurance_eda`).
2. Run:
   - `sql/schema/01_create_tables.sql`
   - `sql/schema/02_constraints.sql`
   - `sql/schema/03_indexes.sql`
   - (optional) `sample_data/01_sample_inserts.sql`
3. Run queries in `sql/queries/`.

> Note: This repository provides the **software artifacts**; your final report (Word/PDF) should reference the GitHub link per the project instructions.
