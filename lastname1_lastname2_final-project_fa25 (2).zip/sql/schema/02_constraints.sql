-- Part 2: Additional constraints and helpful checks

SET search_path TO eda;

-- Policy date sanity
ALTER TABLE policy
  ADD CONSTRAINT policy_dates_chk
  CHECK (termination_date IS NULL OR termination_date >= effective_date);

-- Encounter time sanity
ALTER TABLE encounter
  ADD CONSTRAINT encounter_time_chk
  CHECK (encounter_end IS NULL OR encounter_end >= encounter_start);

-- Claim totals sanity (non-negative)
ALTER TABLE claim
  ADD CONSTRAINT claim_totals_nonneg_chk
  CHECK (total_billed_amt >= 0 AND total_allowed_amt >= 0 AND total_paid_amt >= 0);

ALTER TABLE claim_line
  ADD CONSTRAINT claim_line_amt_nonneg_chk
  CHECK (billed_amt >= 0 AND allowed_amt >= 0 AND paid_amt >= 0 AND units > 0);
