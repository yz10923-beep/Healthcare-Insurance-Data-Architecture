-- Part 4: Physical design (indexes)
-- These are safe, generally useful indexes for OLTP/ODS + analytics.

SET search_path TO eda;

-- Common lookup / join keys
CREATE INDEX IF NOT EXISTS idx_policy_member ON policy(member_id);
CREATE INDEX IF NOT EXISTS idx_policy_product ON policy(product_id);

CREATE INDEX IF NOT EXISTS idx_encounter_member_start ON encounter(member_id, encounter_start);
CREATE INDEX IF NOT EXISTS idx_encounter_provider_start ON encounter(provider_id, encounter_start);

CREATE INDEX IF NOT EXISTS idx_claim_policy_received ON claim(policy_id, claim_received_dt);
CREATE INDEX IF NOT EXISTS idx_claim_status_received ON claim(claim_status, claim_received_dt);
CREATE INDEX IF NOT EXISTS idx_claim_provider_received ON claim(provider_id, claim_received_dt);

CREATE INDEX IF NOT EXISTS idx_claim_line_claim ON claim_line(claim_id);
CREATE INDEX IF NOT EXISTS idx_payment_claim_date ON payment(claim_id, payment_date);

CREATE INDEX IF NOT EXISTS idx_risk_factor_member_date ON risk_factor(member_id, observed_date);

-- Unstructured doc access patterns
CREATE INDEX IF NOT EXISTS idx_doc_member_time ON unstructured_document(member_id, doc_timestamp);
CREATE INDEX IF NOT EXISTS idx_doc_source_time ON unstructured_document(source_id, doc_timestamp);

-- Optional: GIN for JSONB if you query extracted_json
CREATE INDEX IF NOT EXISTS idx_doc_extracted_json_gin ON unstructured_document USING GIN (extracted_json);
