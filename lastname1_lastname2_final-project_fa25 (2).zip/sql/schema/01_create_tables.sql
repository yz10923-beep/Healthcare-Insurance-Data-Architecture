-- Part 2: Logical/Relational schema (DDL)
-- Target DB: PostgreSQL 13+
-- Creates schema: eda

CREATE SCHEMA IF NOT EXISTS eda;
SET search_path TO eda;

-- =========================
-- Core Master Data
-- =========================
CREATE TABLE IF NOT EXISTS member (
  member_id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  external_member_id TEXT UNIQUE,
  first_name        TEXT NOT NULL,
  last_name         TEXT NOT NULL,
  date_of_birth     DATE NOT NULL,
  sex               CHAR(1) CHECK (sex IN ('M','F','U')),
  email             TEXT,
  phone             TEXT,
  address_line1     TEXT,
  address_line2     TEXT,
  city              TEXT,
  state             TEXT,
  postal_code       TEXT,
  created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS provider (
  provider_id       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  npi               TEXT UNIQUE,
  provider_name     TEXT NOT NULL,
  provider_type     TEXT,
  specialty         TEXT,
  phone             TEXT,
  address_line1     TEXT,
  city              TEXT,
  state             TEXT,
  postal_code       TEXT,
  created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plan_product (
  product_id        BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  product_code      TEXT UNIQUE NOT NULL,
  product_name      TEXT NOT NULL,
  product_type      TEXT NOT NULL, -- e.g., HMO/PPO/EPO
  metal_tier        TEXT,          -- e.g., Bronze/Silver/Gold/Platinum
  network_type      TEXT,
  created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS policy (
  policy_id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  policy_number     TEXT UNIQUE NOT NULL,
  member_id         BIGINT NOT NULL REFERENCES member(member_id),
  product_id        BIGINT NOT NULL REFERENCES plan_product(product_id),
  effective_date    DATE NOT NULL,
  termination_date  DATE,
  policy_status     TEXT NOT NULL, -- Active/Terminated/etc.
  created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- =========================
-- Clinical / Encounter Data
-- =========================
CREATE TABLE IF NOT EXISTS encounter (
  encounter_id      BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  member_id         BIGINT NOT NULL REFERENCES member(member_id),
  provider_id       BIGINT REFERENCES provider(provider_id),
  encounter_start   TIMESTAMP NOT NULL,
  encounter_end     TIMESTAMP,
  encounter_type    TEXT,          -- outpatient/inpatient/telehealth
  facility_name     TEXT,
  created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS diagnosis (
  diagnosis_id      BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  encounter_id      BIGINT NOT NULL REFERENCES encounter(encounter_id) ON DELETE CASCADE,
  icd10_code        TEXT NOT NULL,
  diagnosis_desc    TEXT,
  is_primary        BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS procedure (
  procedure_id      BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  encounter_id      BIGINT NOT NULL REFERENCES encounter(encounter_id) ON DELETE CASCADE,
  cpt_hcpcs_code    TEXT NOT NULL,
  procedure_desc    TEXT
);

-- =========================
-- Claims / Payments
-- =========================
CREATE TABLE IF NOT EXISTS claim (
  claim_id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  claim_number      TEXT UNIQUE NOT NULL,
  policy_id         BIGINT NOT NULL REFERENCES policy(policy_id),
  encounter_id      BIGINT REFERENCES encounter(encounter_id),
  provider_id       BIGINT REFERENCES provider(provider_id),
  claim_received_dt DATE NOT NULL,
  claim_status      TEXT NOT NULL, -- Received/Adjudicated/Denied/Paid
  total_billed_amt  NUMERIC(12,2) NOT NULL DEFAULT 0,
  total_allowed_amt NUMERIC(12,2) NOT NULL DEFAULT 0,
  total_paid_amt    NUMERIC(12,2) NOT NULL DEFAULT 0,
  created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS claim_line (
  claim_line_id     BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  claim_id          BIGINT NOT NULL REFERENCES claim(claim_id) ON DELETE CASCADE,
  line_number       INTEGER NOT NULL,
  service_from_dt   DATE NOT NULL,
  service_to_dt     DATE NOT NULL,
  cpt_hcpcs_code    TEXT,
  revenue_code      TEXT,
  units             NUMERIC(10,2) NOT NULL DEFAULT 1,
  billed_amt        NUMERIC(12,2) NOT NULL DEFAULT 0,
  allowed_amt       NUMERIC(12,2) NOT NULL DEFAULT 0,
  paid_amt          NUMERIC(12,2) NOT NULL DEFAULT 0,
  denial_reason     TEXT,
  UNIQUE (claim_id, line_number)
);

CREATE TABLE IF NOT EXISTS payment (
  payment_id        BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  claim_id          BIGINT NOT NULL REFERENCES claim(claim_id) ON DELETE CASCADE,
  payment_date      DATE NOT NULL,
  payment_method    TEXT,          -- EFT/Check/etc.
  paid_amt          NUMERIC(12,2) NOT NULL,
  check_eft_number  TEXT
);

-- =========================
-- Risk / Lifestyle / SDoH
-- =========================
CREATE TABLE IF NOT EXISTS risk_factor (
  risk_factor_id    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  member_id         BIGINT NOT NULL REFERENCES member(member_id) ON DELETE CASCADE,
  factor_type       TEXT NOT NULL, -- smoking, alcohol, inactivity, diet, stress, etc.
  factor_value      TEXT,
  observed_date     DATE,
  source            TEXT           -- survey/claim/clinical/wearable
);

-- =========================
-- Unstructured / Hybrid data (Data Lake linkage)
-- =========================
CREATE TABLE IF NOT EXISTS data_source (
  source_id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  source_name       TEXT NOT NULL,
  source_type       TEXT NOT NULL, -- EHR/Claims/Survey/Wearable/SocialMedia/CDC/etc.
  ingestion_method  TEXT,          -- batch/stream/api
  owner             TEXT
);

CREATE TABLE IF NOT EXISTS unstructured_document (
  document_id       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  member_id         BIGINT REFERENCES member(member_id) ON DELETE SET NULL,
  source_id         BIGINT REFERENCES data_source(source_id),
  doc_type          TEXT NOT NULL, -- note/pdf/text/social_post/etc.
  doc_uri           TEXT NOT NULL, -- link into data lake / blob storage
  doc_timestamp     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  doc_hash          TEXT,
  extracted_json    JSONB          -- optional (NLP output)
);
