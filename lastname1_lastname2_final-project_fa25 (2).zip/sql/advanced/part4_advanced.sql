-- Part 4: Advanced / Physical design extras

SET search_path TO eda;

-- 1) Materialized view for monthly cost rollups (optional)
CREATE MATERIALIZED VIEW IF NOT EXISTS mv_monthly_cost_by_product AS
SELECT
  date_trunc('month', c.claim_received_dt)::date AS month,
  pp.product_code,
  SUM(c.total_allowed_amt) AS allowed_total,
  SUM(c.total_paid_amt)    AS paid_total,
  COUNT(*)                 AS claim_count
FROM claim c
JOIN policy pol ON pol.policy_id=c.policy_id
JOIN plan_product pp ON pp.product_id=pol.product_id
GROUP BY 1,2;

-- Refresh example:
-- REFRESH MATERIALIZED VIEW mv_monthly_cost_by_product;

-- 2) View for a denormalized ODS-style claim line fact
CREATE OR REPLACE VIEW v_claim_line_fact AS
SELECT
  c.claim_id,
  c.claim_number,
  c.claim_status,
  c.claim_received_dt,
  pol.policy_number,
  m.member_id,
  m.external_member_id,
  pp.product_code,
  pr.provider_id,
  pr.npi,
  cl.claim_line_id,
  cl.line_number,
  cl.service_from_dt,
  cl.service_to_dt,
  cl.cpt_hcpcs_code,
  cl.units,
  cl.billed_amt,
  cl.allowed_amt,
  cl.paid_amt
FROM claim_line cl
JOIN claim c ON c.claim_id=cl.claim_id
JOIN policy pol ON pol.policy_id=c.policy_id
JOIN member m ON m.member_id=pol.member_id
LEFT JOIN plan_product pp ON pp.product_id=pol.product_id
LEFT JOIN provider pr ON pr.provider_id=c.provider_id;

-- 3) Partition-ready pattern (documentation only)
-- For very large claims tables, consider RANGE partitioning by claim_received_dt (monthly).
-- See docs/physical_design.md for guidance.
