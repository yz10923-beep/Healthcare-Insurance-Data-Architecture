-- Part 3: Queries (EDA/ODS analytics examples)
SET search_path TO eda;

-- Q1: Claim cost trend by month and product
-- (supports forecasting chronic disease costs and utilization)
SELECT
  date_trunc('month', c.claim_received_dt)::date AS month,
  pp.product_code,
  pp.product_name,
  COUNT(DISTINCT c.claim_id) AS claims,
  SUM(c.total_allowed_amt)   AS allowed_total,
  SUM(c.total_paid_amt)      AS paid_total
FROM claim c
JOIN policy pol ON pol.policy_id = c.policy_id
JOIN plan_product pp ON pp.product_id = pol.product_id
GROUP BY 1,2,3
ORDER BY 1,2;

-- Q2: Members with diabetes diagnosis and their last encounter + last paid claim
WITH diab AS (
  SELECT DISTINCT e.member_id
  FROM encounter e
  JOIN diagnosis d ON d.encounter_id = e.encounter_id
  WHERE d.icd10_code LIKE 'E11%'
),
last_enc AS (
  SELECT member_id, MAX(encounter_start) AS last_encounter_start
  FROM encounter
  GROUP BY member_id
),
last_paid AS (
  SELECT pol.member_id, MAX(c.claim_received_dt) AS last_paid_claim_dt
  FROM claim c
  JOIN policy pol ON pol.policy_id = c.policy_id
  WHERE c.claim_status='Paid'
  GROUP BY pol.member_id
)
SELECT
  m.member_id,
  m.first_name,
  m.last_name,
  le.last_encounter_start,
  lp.last_paid_claim_dt
FROM diab
JOIN member m ON m.member_id = diab.member_id
LEFT JOIN last_enc le ON le.member_id = m.member_id
LEFT JOIN last_paid lp ON lp.member_id = m.member_id
ORDER BY le.last_encounter_start DESC NULLS LAST;

-- Q3: Risk factor prevalence (example: smoking) by age band
WITH age_calc AS (
  SELECT
    member_id,
    EXTRACT(YEAR FROM age(current_date, date_of_birth))::int AS age_years
  FROM member
),
band AS (
  SELECT
    member_id,
    CASE
      WHEN age_years < 18 THEN '0-17'
      WHEN age_years BETWEEN 18 AND 34 THEN '18-34'
      WHEN age_years BETWEEN 35 AND 49 THEN '35-49'
      WHEN age_years BETWEEN 50 AND 64 THEN '50-64'
      ELSE '65+'
    END AS age_band
  FROM age_calc
)
SELECT
  b.age_band,
  rf.factor_value AS smoking_status,
  COUNT(*) AS members
FROM risk_factor rf
JOIN band b ON b.member_id = rf.member_id
WHERE rf.factor_type='smoking'
GROUP BY 1,2
ORDER BY 1,2;

-- Q4: Join structured member/claim data to unstructured NLP output
SELECT
  m.external_member_id,
  ud.doc_type,
  ud.doc_timestamp,
  ud.doc_uri,
  ud.extracted_json->>'sentiment' AS sentiment,
  (SELECT SUM(c.total_paid_amt)
   FROM claim c
   JOIN policy pol ON pol.policy_id=c.policy_id
   WHERE pol.member_id=m.member_id
  ) AS lifetime_paid
FROM unstructured_document ud
LEFT JOIN member m ON m.member_id=ud.member_id
ORDER BY ud.doc_timestamp DESC;
