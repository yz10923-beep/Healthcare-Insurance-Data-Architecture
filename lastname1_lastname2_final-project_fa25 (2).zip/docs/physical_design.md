# Physical Database Design Notes (Part 4)

This project focuses on an **ODS/OLTP-style relational schema** that also links to unstructured data in a data lake (hybrid model).

## Indexing choices
- Composite btree indexes for frequent filters/joins:
  - `claim(policy_id, claim_received_dt)` for member/policy rollups
  - `encounter(member_id, encounter_start)` for “latest encounter” patterns
- GIN index for `unstructured_document.extracted_json` for NLP-derived fields.

## Partitioning (optional / future)
For large-scale claims:
- Partition `claim` by `claim_received_dt` (monthly RANGE partitions).
- Keep local indexes per partition.
- Maintain summary MVs (e.g., `mv_monthly_cost_by_product`) for dashboards/forecasting inputs.

## Clustering / maintenance
- Consider `CLUSTER` on `idx_claim_policy_received` if read-heavy analytic workloads dominate.
- Routine `VACUUM`/`ANALYZE` for cost-based optimizer accuracy.
